typedef unsigned char byte;
void setsteps(double p, double r);
void setmetrics(double p, double q);
void new_codec(int n, int M);
void free_codec(void);
int compress(const byte *x, int n, int t=0);
int expand(byte *xr, byte *y, double **ccs, int N, int M, int n, double r, int t=0);
