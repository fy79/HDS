#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <memory.h>
#include <math.h>
#include <float.h>
#include <iostream>
using namespace std;
#include "codec.h"

void getccs(double **ccs, double p, double r, int n, int m){
    for(int j=0; j<m; j++){
        ccs[n][j] = 1.0;
    }
    double scaleup0 = pow(1-p,-r), scaleup1 = pow(p,-r), shift = m*(1-pow(p,r));
    for(int i=n-1; i>=0; i--){
        memset(ccs[i], 0, m*sizeof(double));
        for(int j=0; j<m; j++){
            double alpha = j*scaleup0, beta = (j+1)*scaleup0, temp;
            if(alpha>=m){
                break;
            }else if(beta>=m){
                temp = (ceil(alpha)-alpha)*ccs[i+1][int(alpha)];
                for(int k=ceil(alpha); k<m; k++){
                    temp += ccs[i+1][k];
                }
            }else{
                temp = (ceil(alpha)-alpha)*ccs[i+1][int(alpha)] + (beta-int(beta))*ccs[i+1][int(beta)];
                for(int k=ceil(alpha); k<int(beta); k++){
                    temp += ccs[i+1][k];
                }
            }
            ccs[i][j] = (1-p)*temp;
        }
        for(int j=m-1; j>=0; j--){
            double alpha = (j-shift)*scaleup1, beta = ((j+1)-shift)*scaleup1, temp;
            if(beta<=0){
                break;
            }else if(alpha<=0){
                temp = (beta-int(beta))*ccs[i+1][int(beta)];
                for(int k=0; k<int(beta); k++){
                    temp += ccs[i+1][k];
                }
            }else{
                temp = (ceil(alpha)-alpha)*ccs[i+1][int(alpha)] + (beta-int(beta))*ccs[i+1][int(beta)];
                for(int k=ceil(alpha); k<int(beta); k++){
                    temp += ccs[i+1][k];
                }
            }
            ccs[i][j] += p*temp;
        }
    }
    
//    FILE *fccs = fopen("ccs.txt", "wt");
//    for(int i=0; i<=n; i++){
//        for (int j=0; j<m; j++){
//            fprintf(fccs, "%f\t", ccs[i][j]);
//        }
//        fprintf(fccs, "\n");
//    }
//    fclose(fccs);

    for(int i=0; i<=n; i++){
        for(int j=0; j<m; j++){
            ccs[i][j] = log(ccs[i][j]);
        }
    }
}

int main(int argc, char *argv[]){
    int n=(1<<8), t=16, M=(1<<10);// M is the number of surviving paths
    double p=0.5, r=0.5, q=0.1;
//    double hp = -p*log2(p) - (1-p)*log2(1-p);
    setsteps(p,r);
    setmetrics(p,q);
    byte *x = new byte[3*n], *y = x+n, *xr = y+n;
    new_codec(n,M);

    // initialize CCS array
    int N=(1<<10);  // number of segments
    double **ccs = new double*[n-t+1];
    for(int i=0; i<(n-t)+1; i++){// for each stage
        ccs[i] = new double[N];
    }
    getccs(ccs, p, r, n-t, N);
    cout<<"CCS initialization over!"<<endl;

    // loop for trials
    double fer = 0;
    clock_t start = clock();
    for(int l=0,nefs=0; l<(1<<16); l++){
        for(int i=0; i<n; i++){
            x[i] = (rand()<RAND_MAX*p);
            y[i] = x[i]^(rand()<RAND_MAX*q);
        }
        compress(x,n,t);
        expand(xr,y,ccs,N,M,n,r,t);
        nefs += (memcmp(x,xr,n)!=0);
        fer = nefs/double(l+1);
        if(nefs>=(1<<8)) break;
    }
    clock_t finish = clock();
    double duration = (double)(finish-start)/CLOCKS_PER_SEC;
    printf("%.0f ms\n", duration*1e3);
    
    printf("FER: %f\n", fer);
    free_codec();
    delete[] x;
    for(int i=0; i<(n-t)+1; i++){
        delete[] ccs[i];
    }
    delete[] ccs;

    return 0;
}
