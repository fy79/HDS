#include <iostream>
using namespace std;
#include <math.h>
#include <float.h>

void read_code(FILE *fp, int &n, int &m, int* &ir, int* &jc){
    // The parity-check matrix H is an nxm sparse matrix
    fscanf(fp, "%d", &n);// number of v-nodes
    fscanf(fp, "%d", &m);// number of c-nodes
    int maxCdeg, temp;
    fscanf(fp, "%d", &maxCdeg);// maximum degree of c-nodes
    jc = new int[m*maxCdeg];// jc[k]: the index of the v-node that is connected with the k-th edge
    ir = new int[m+1]; ir[0] = 0;// ir[j]: accumulated degrees of c-nodes
    for(int j=0,k=0; j<m; j++){// j: index of c-nodes; k: index of edges numbered from c-nodes' viewpoint
        ir[j+1] = ir[j];
        for(int i=0; i<maxCdeg; i++){
            fscanf(fp, "%d", &temp);
            if(temp){
                jc[k++] = temp - 1;// the k-th edge connects the j-th c-node with the jc[k]-th v-node
                ir[j+1]++;
            }
        }
    }
}

int beliefPropagation(int *ir, int *jc, int m, int n, char *sid, char *syn, char *rec, char *bmem, double *dmem, double pb, double pc){
    // ellr: LLRs of edges; cllr: LLRs of c-nodes; vllr: LLRs of v-nodes. // vllr and cllr share the same bulk of memory
    char *ellr_sgn = bmem, *cllr_sgn = ellr_sgn+ir[m];
    double *vllrin = dmem, *ellr = vllrin+n, *cllr = ellr+ir[m], *vllr = cllr;
    
    //initialize variable-to-check messages
    for(int i=0; i<n; i++){
        vllrin[i] = (1-2*sid[i])*log((1-pc)/pc) + log((1-pb)/pb);
    }
    for(int k=0; k<ir[m]; k++){// for each edge
        ellr[k] = vllrin[jc[k]];
    }
    
    for(int iteration=0, sameCount=0; iteration<100; iteration++){
        //Step 1: compute check-to-variable messages
        for(int k=0; k<ir[m]; k++){// for each edge
            ellr_sgn[k] = (ellr[k]<0);
            ellr[k] = -log(tanh(max(fabs(ellr[k]), DBL_MIN)/2));
        }
        
        memset(cllr, 0, m*sizeof(double));
        memcpy(cllr_sgn, syn, m);
        for (int j=0; j<m; j++) {// for each syndrome bit
            for (int k=ir[j]; k<ir[j+1]; k++) {
                cllr_sgn[j] ^= ellr_sgn[k];
                cllr[j] += ellr[k];
            }
            for (int k=ir[j]; k<ir[j+1]; k++) {
                ellr_sgn[k] ^= cllr_sgn[j];
                ellr[k] = -log(tanh(max(cllr[j]-ellr[k], DBL_MIN)/2));
                ellr[k] *= (1-2*ellr_sgn[k]);
            }
        }
        
        //Step 2: compute variable-to-check messages
        int ndiffs = 0;
        memcpy(vllr, vllrin, n*sizeof(double));// vllr <= vllrin
        for(int k=0; k<ir[m]; k++){// for each edge
            vllr[jc[k]] += ellr[k];
        }
        for(int k=0; k<ir[m]; k++){// for each edge
            ellr[k] = vllr[jc[k]] - ellr[k];
        }
        for(int i=0; i<n; i++){
            char temp = (vllr[i]<0);
            ndiffs += (rec[i]^temp);
            rec[i] = temp;
        }
        
        //Step 3: test convergence and syndrome condition
        if(ndiffs){// different
            sameCount = 0;
            memcpy(cllr_sgn, syn, m);
            for (int j=0; j<m; j++) {// for each syndrome bit
                for (int k=ir[j]; k<ir[j+1]; k++) {
                    cllr_sgn[j] ^= rec[jc[k]];
                }
            }
            for(int j=0; j<m; j++){
                if(cllr_sgn[j])
                    break;
                else if(j==m-1)
                    return 1; //all syndrome checks satisfied
                else;
            }
        }else{// the same
            if(sameCount==4) return 0; //convergence (to wrong answer)
            else sameCount++;
        }
    }
    return 0;
}

int main(int argc, const char* argv[]){
    int n, m, *ir=NULL, *jc=NULL;
    FILE *fp = fopen("../../../../../codes/irReg/PEGirReg520x1024.txt", "rt");
    if(!fp){
        cout<<"LDPC code file doesn't exist!"<<endl;
        return 1;
    }else{
        read_code(fp, n, m, ir, jc);
        fclose(fp);
    }
    
	char *src = new char[3*n+m], *rec = src+n, *sid = rec+n, *syn = sid+n;
    char *bmem = new char[ir[m]+m];
    double *dmem = new double[ir[m]+2*n];
    
    double pb = 0.5, pc = 0.1;
    double fer = 0.0, ber = 0.0;
    int ntests = (1<<16), nefs = 0, nebs = 0;   // number of erroneous frames (nefs); number of erroneous bits (nebs)
    
    clock_t start = clock();
    for(int l=0; l<ntests; l++){
        // step 1: generate source and side information
        for(int i=0; i<n; i++){
            src[i] = (rand()<(RAND_MAX*pb));
            sid[i] = (src[i]^(rand()<(RAND_MAX*pc)));
        }

        // step 2: encoding via s = xH
        memset(syn, 0, m);
        for(int j=0; j<m; j++){// for each c-node
            for(int k=ir[j]; k<ir[j+1]; k++){// for each edge
                syn[j] ^= src[jc[k]];
            }
        }
        
        // step 3: decoding
		beliefPropagation(ir, jc, m, n, sid, syn, rec, bmem, dmem, pb, pc);
        
        // step 4: correctness test
		int nerrs = 0;
		for(int i=0; i<n; i++)  nerrs += (rec[i]^src[i]);
        nebs += nerrs;
        nefs += (nerrs>0);
        ber = nebs/double(n*(l+1));
        fer = nefs/double(l+1);
        if (nefs>=(1<<8)) break;
	}
    clock_t end = clock();
    cout<<"Running time: "<<(double)(end-start)/CLOCKS_PER_SEC<<"s"<<endl;
    
    cout<<"FER = "<<fer<<", "<<"BER = "<<ber<<endl;

    delete[] jc;
    free(ir);
    delete[] src;
    delete[] bmem;
    delete[] dmem;
    return 0;
}
