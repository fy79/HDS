function fhds(n,r,i,w)
% n: code length
% r: code rate
% i: symbol index, 1<=i<=n
% w: length-n ternary sequence with symbols {-1,0,+1}
global hds;
global hdsapp;
global pmf;
global pmfspecial;
if i<=n
    w(i) = 0;
    fhds(n,r,i+1,w);    
    w(i) = 1;
    fhds(n,r,i+1,w);
    if i>1 && any(w(1:(i-1)))
        w(i) = -1;  
        fhds(n,r,i+1,w);
    end
else % i>n
    d = sum(abs(w));
    if d>0
        tau = (1-2^(-r))*abs(sum(w.*2.^((1:n)*r)));
        pmf(d, ceil(tau)+2^ceil(n*r)+1) = pmf(d, ceil(tau)+2^ceil(n*r)+1) + 1;        
        if tau<1
            if d<n
                hds(d) = hds(d) + (1-tau);
                hdsapp(d) = hdsapp(d) + 1/2;                
            else
                hds(d) = hds(d) + 1;
                hdsapp(d) = hdsapp(d) + 1;   
            end
        end
    end    
    
    if d==(n-1)
        pmfspecial(w==0, ceil(tau)+2^ceil(n*r)+1) = pmfspecial(w==0, ceil(tau)+2^ceil(n*r)+1) + 1;
    end
end
end

























