#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <memory.h>
#include <math.h>
#include <float.h>
#include <iostream>
using namespace std;

uint8_t src[BUFSIZ], str[BUFSIZ], side[BUFSIZ];	// side information is useless in this program actually
int **hds=NULL;

// local variables used in this file
double q0, q1;  // 0 -> [0,q0) and 1 -> [q1,1)

// parameters to control the AC codec
////////////////////////////////////////////////////////////////////////////////////////////////
const int DEPTH = 32;
const unsigned HRNG = (1U<<(DEPTH-1));    // half the range
const unsigned QRNG = (1U<<(DEPTH-2));    // quarter the range
const unsigned MASK = HRNG|(HRNG-1);

// get one source symbol
uint8_t get_symbol(unsigned low, unsigned high, unsigned code){
    if(code >= (low + unsigned((high-low)*q0 + q0 + 0.5)))      return 1;
    else if(code < (low + unsigned((high-low)*q1 + q1 + 0.5)))  return 0;
    else return 'a';// ambiguity
}

// remove the source symbol from the buffer
void remove_symbol(unsigned &low, unsigned &high, unsigned &code, int &ptr, uint8_t s){
    if(s)   low += unsigned((high-low)*q1 + q1 + 0.5);
    else    high = low + unsigned((high-low)*q0 + q0 + 0.5) - 1;
    while(!((high^low)&HRNG)){
        low  <<= 1;
        high <<= 1; high |= 1;
        code <<= 1; code |= str[ptr++];
    }
    low &= MASK; high &= MASK; code &= MASK;
    while((high&QRNG)<(low&QRNG)){
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
        code -= QRNG; code <<= 1; code |= str[ptr++];
    }
}

void recursive_search(unsigned low, unsigned high, unsigned code, int ptr, int depth, int n, int ham_dist){
    if(depth<n){
        uint8_t b = src[depth];
        uint8_t s = get_symbol(low, high, code);
        if(s=='a'){
            hds[depth+1][ham_dist]++;
            hds[depth+1][ham_dist+1]++;
            // 0-branch
            unsigned low_cpy = low, high_cpy = high, code_cpy = code; int ptr_cpy = ptr;
            remove_symbol(low_cpy, high_cpy, code_cpy, ptr_cpy, 0);
            recursive_search(low_cpy, high_cpy, code_cpy, ptr_cpy, depth+1, n, ham_dist+b);
            // 1-branch
            remove_symbol(low, high, code, ptr, 1);
            recursive_search(low, high, code, ptr, depth+1, n, ham_dist+(!b));
        }else{
            hds[depth+1][ham_dist+(s^b)]++;
            remove_symbol(low, high, code, ptr, s);
            recursive_search(low, high, code, ptr, depth+1, n, ham_dist+(s^b));
        }
    }
}

int expand(int n, double p, double r){
    unsigned low = 0, high = MASK, code = 0; int ptr = 0;
    for(int i=0; i<DEPTH; i++){
        code <<= 1; code |= str[ptr++];
    }
    int depth=0, ham_dist=0;
    hds[depth][ham_dist]++;
    recursive_search(low, high, code, ptr, depth, n, ham_dist);
    return 0;
}

// encode one source symbol 's'
void encode_symbol(unsigned &low, unsigned &high, int &underflow, int &ptr, uint8_t s){
    if(s)   low += unsigned((high-low)*q1 + q1 + 0.5);
    else    high = low + unsigned((high-low)*q0 + q0 + 0.5) - 1;
    
    while(!((high^low)&HRNG)){
        bool msb = (high&HRNG)>0;
        str[ptr++] = msb;
        while(underflow){
            str[ptr++] = !msb;
            underflow--;
        }
        low <<= 1; high <<= 1; high |= 1;
    }
    low &= MASK; high &= MASK;
    while((high&QRNG)<(low&QRNG)){
        underflow++;
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
    }
}

int compress(uint8_t *src, int n, double p, double r){
    int ptr = 0, underflow = 0;
    unsigned low = 0, high = MASK;
    memset(str, 0, BUFSIZ);
    for(int i=0; i<n; i++){
        encode_symbol(low, high, underflow, ptr, src[i]);
    }
    str[ptr] = 1;
    return ptr;
}

// generate source and side information
void prepare(uint8_t *src, uint8_t *side, unsigned n, double p_bias, double p_crx=0.1){
    for(int i=0; i<n; i++){
        bool x = (rand()<(RAND_MAX*p_bias)), z = (rand()<(RAND_MAX*p_crx));
        src[i] = x;
        side[i] = x^z;
    }
}

int main(int argc, char *argv[]){
	double p = atof(argv[1]);		// bias probability of the source
	int n = atoi(argv[2]);		// block length
	int seed = atoi(argv[3]);	// initial seed
	int num_tries = atoi(argv[4]);
	FILE *fp = fopen(argv[5], "wt");
	if(fp==NULL){
		cout<<"File open fails!"<<endl;
		return 1;
	}	
	double q = (sqrt(5)-1)/2, r = log(q)/log(p);
	if(argc>=8){
		if(!strcmp(argv[6], "-q")){
			q = atof(argv[7]);
			r = log(q)/log(p);
		}else if(!strcmp(argv[6], "-r")){
			r = atof(argv[7]);
			q = pow(p,r);
		}else{
			printf("Input error!\n");
			return 1;
		}
	}

    q0 = q;     // the upper bound of '0'
    q1 = 1-q;   // the lower bound of '1'

	cout<<"************************Configurations**********************"<<endl;
	cout<<"p = "<<p<<endl;
	cout<<"q = "<<q<<endl;
	cout<<"n = "<<n<<endl;
	cout<<"R = "<<-r*(p*log2(p)+(1-p)*log2(1-p))<<endl;
    cout<<"q0 = "<<q0<<", "<<"q1 = "<<q1<<endl;
	cout<<"number of tries = "<<num_tries<<endl;
	cout<<"********************End of Configurations*******************"<<endl<<endl;

	hds = new int*[n+1];
	for(int depth=0; depth<=n; depth++){
		hds[depth] = new int[depth+1];
		memset(hds[depth], 0, sizeof(int)*(depth+1));
	}

	srand(seed); // srand((unsigned)_rdtsc());
	double R = 0.0;
	clock_t start = clock();
	for(int i=0; i<num_tries; i++){
		prepare(src, side, n, p);
		int m = compress(src, n, p, r);
		R += m;
		expand(n, p, r);
	}
	clock_t finish = clock();
	double duration = (double)(finish-start)/CLOCKS_PER_SEC;
	cout<<"Elapsed time is "<<duration<<" seconds."<<endl;
	cout<<"Practical R = "<<R/(n*num_tries)<<endl<<endl;

	unsigned prev_num_paths = num_tries;
	for(unsigned depth=1; depth<=n; depth++){
		cout<<"***Depth-"<<depth<<" HDS:***"<<endl;
		unsigned curr_num_paths = 0;
		for(unsigned i=0; i<=depth; i++){
			cout<<"Hamming Distance "<<i<<": "<<hds[depth][i]/(double)num_tries<<endl;
			curr_num_paths += hds[depth][i];
			if(depth==n && i>0)	fprintf(fp, "%f\n", hds[depth][i]/(double)num_tries);
		}
		cout<<"***Expansion Factor: "<<curr_num_paths/(double)prev_num_paths<<"***"<<endl<<endl;
		prev_num_paths = curr_num_paths;
	}

	if(fp)	fclose(fp);
	return 0;
}
