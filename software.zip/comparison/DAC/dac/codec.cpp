#include <stdio.h>
#include <math.h>
#include <float.h>
#include <stdlib.h>
#include <memory.h>
#include <iostream>
#include "codec.h"

////////////////////////////////////////////////////////////////////////////////////////////////
static double steps[3];
void setsteps(double p, double r){
    // [0, steps[2], steps[0], steps[1], 1)
    steps[0] = 1-p;
    steps[1] = powf(1-p,r); // upper bound of "0": (1-p)^r => [0, steps[1])
    steps[2] = 1-powf(p,r); // lower bound of "1": (1-p^r) => [steps[2], 1)
}

////////////////////////////////////////////////////////////////////////////////////////////////
static double lgp[2], lgq[2];
void setmetrics(double p, double q){
    lgp[0] = log(1-p);
    lgp[1] = log(p);
    lgq[0] = log(1-q);
    lgq[1] = log(q);
}

////////////////////////////////////////////////////////////////////////////////////////////////
struct NODE{
    unsigned low, high, code; int ptr;
    double exmetric, metric;
    NODE *parent, *kids[2];
};
static NODE **paths=NULL;
static NODE *nodes=NULL;
static byte *str=NULL;/* This is the i/o buffer    */
void new_codec(int n, int M){
    str = new byte[n];
    nodes = new NODE[(M<<1)*n];
    paths = new NODE*[(M<<1)];
}
void free_codec(void){
    delete[] str;
    delete[] nodes;
    delete[] paths;
}

////////////////////////////////////////////////////////////////////////////////////////////////
const int WIDTH = 32;
const unsigned HRNG = (1U<<(WIDTH-1));    // half of the range
const unsigned QRNG = (1U<<(WIDTH-2));    // quarter of the range
const unsigned MASK = HRNG|(HRNG-1);

////////////////////////////////////////////////////////////////////////////////////////////////
static void encode_symbol(unsigned &low, unsigned &high, int &ptr, int &underflow, byte x, bool b=true){
    int a = b+(b&x);
    if(x) low += int((high-low+1.0)*steps[a]+0.5);  // update the lower bound of "1"
    else  high = low + int((high-low+1.0)*steps[a]-0.5);    // update the upper bound of "0"
    while(!((high^low)&HRNG)){
        bool msb = (high&HRNG)>0;
        str[ptr++] = msb;
        while(underflow){
            str[ptr++] = !msb;
            underflow--;
        }
        low <<= 1; high <<= 1; high |= 1;
    }
    while((high&QRNG)<(low&QRNG)){
        underflow++;
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
    }
}
int compress(const byte *x, int n, int t){
    int ptr=0, underflow=0;
    unsigned low=0, high=MASK;
    memset(str, 0, n*sizeof(byte));
    for(int i=0; i<n; i++){
        encode_symbol(low, high, ptr, underflow, x[i], i<(n-t));
    }
    str[ptr] = 1;
    return ptr;
}

////////////////////////////////////////////////////////////////////////////////////////////////
static NODE *create_root(int &nNodes){
    NODE *root = nodes+(nNodes++);
    root->low = 0; root->high = MASK; root->code = 0; root->ptr = 0;    
    for(int i=0; i<WIDTH; i++){
        root->code <<= 1;
        root->code |= str[root->ptr++];
    }
    root->exmetric = 0.0;
    root->parent = NULL; root->kids[0] = NULL; root->kids[1] = NULL;
    return root;
}
static void remove_symbol(unsigned &low, unsigned &high, unsigned &code, int &ptr, byte x, bool b=true){
    int a = b+(b&x);
    if(x) low += int((high-low+1.0)*steps[a]+0.5);
    else  high = low + int((high-low+1.0)*steps[a]-0.5);
    while(!((high^low)&HRNG)){
        low  <<= 1;
        high <<= 1;	high |= 1;
        code <<= 1;	code |= str[ptr++];
    }
    while((high&QRNG)<(low&QRNG)){
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
        code -= QRNG; code <<= 1; code |= str[ptr++];
    }
}
static NODE *create_kid(NODE *parent, int &nNodes, byte x, double yinf, const double *ccs, int N, double r){
    NODE *kid = nodes+(nNodes++);
    kid->exmetric = parent->exmetric + yinf + (1-r)*lgp[x]; // update extrinsic metric
    memcpy(kid, parent, 3*sizeof(unsigned)+sizeof(int));// (low, high, code, ptr)
    remove_symbol(kid->low, kid->high, kid->code, kid->ptr, x, r<1);
    kid->metric = kid->exmetric;
    if(r<1){
        double u = ((kid->code)-(kid->low))/((kid->high)-(kid->low)+1.0);
        kid->metric += ccs[int(u*N)]; // overall metric
    }
    kid->parent = parent; kid->kids[0] = NULL; kid->kids[1] = NULL;
    parent->kids[x] = kid;
    return kid;
}
byte get_symbol(unsigned low, unsigned high, unsigned code, bool b=true){
    if((code-low)<int((high-low+1.0)*steps[b<<1]+0.5))      return 0;   // < 1-p^r or (1-p)
    else if((code-low)>int((high-low+1.0)*steps[b]-0.5))    return 1;   // >= (1-p)^r or (1-p)
    else                                                    return 2;
}
static void extend(int &nNodes, int &nPaths, byte y, const double *ccs, int N, double r){
    int nKids = nPaths;
    for(int k=0; k<nPaths; k++){// for each active path
        byte x = get_symbol(paths[k]->low, paths[k]->high, paths[k]->code, r<1);
        if(x==2){// fork node
            paths[nKids++] = create_kid(paths[k], nNodes, y, lgq[0], ccs, N, r);
            paths[k] = create_kid(paths[k], nNodes, !y, lgq[1], ccs, N, r);
        }else{// 0/1 node
            paths[k] = create_kid(paths[k], nNodes, x, lgq[x^y], ccs, N, r);
        }
    }
    nPaths = nKids;
}
static int compare(const void *a, const void *b){
    return ((*(NODE**)b)->metric) - ((*(NODE**)a)->metric);
}
static void traceback(byte *xr, NODE *leaf, int n){
    NODE *now = leaf;
    for(int i=(n-1); i>=0; i--){
        xr[i] = (now==(now->parent->kids[1]));
        now = (now->parent);
    }
}
int expand(byte *xr, byte *y, double **ccs, int N, int M, int n, double r, int t){
    int nNodes=0, nPaths=0;
    paths[nPaths++] = create_root(nNodes);
    for(int i=0; i<n; i++){
        extend(nNodes, nPaths, y[i], (i<(n-t))?ccs[i+1]:NULL, N, (i<(n-t))?r:1);
        if(i<(n-t-1)){
            qsort(paths, nPaths, sizeof(NODE*), compare); // sort paths in the descending order of metric
            nPaths = fmin(nPaths,M);
        }
    }
    for(int j=1; j<nPaths; j++){
        if((paths[j]->metric) > (paths[0]->metric)){
            paths[0] = paths[j];
        }
    }
    traceback(xr, paths[0], n);
    return nNodes;
}



// (10,111... - 00,000...) = (11,000... - 00,000...) - 1    = 3*N/4 - 1
// (10,000... - 00,111...) = (10,000... - 01,000...) + 1    = N/4 + 1
// (11111... - 00000...)                                    = N - 1
// (11000... - 00111...) = (11000... - 01000...) + 1        = N/2 + 1
