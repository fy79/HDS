%% to generate Fig. 2(a)
figure(1);
r = ones(34,1);
%% J_1=K_{2,2}
for i=0:32
    r(i+2) = log2(fsolve(@(x) x.^(i+1)-x.^i-1, 1.5));
end
stairs(r,0:33); hold on;
%% J_{2,1}
for i=0:32
    r(i+2) = log2(fsolve(@(x) x.^(i+2)-x.^i-1, 1.5));
end
stairs(r,0:33);
%% J_{2,2}
for i=0:32
    r(i+2) = log2(fsolve(@(x) x.^(i/2+1)-x.^(i/2)-1, 1.5));
end
stairs(r,0:33);
%%
grid on;
xlabel({'$r$'}, 'interpreter', 'latex', 'fontsize', 16);
legend({'$J_1$', '$J_{2,1}$', '$J_{2,2}$'}, 'interpreter', 'latex', 'fontsize', 16);

%% to generate Fig. 2(b)
figure(2);
%% psi(1)
psi = zeros(1024,1);
for r=(128:1024)/1024
    J = -floor(log2(2^r-1)/r);
    psi(r*1024) = sum(1-(1-2^(-r))*2.^((1:J)*r));
end
semilogy((128:1024)/1024, psi(128:1024)); hold on;
%% psi(2)
psi = zeros(1024,1);
for r=(128:1024)/1024
    J = -floor(log2(2^(2*r)-1)/r);
    for j=1:J
        K = ceil((log2(2^(-j*r)-1+2^(-r))-log2(2^r-1))/r);
        psi(r*1024) = psi(r*1024) + sum((1-(1-2^(-r))*2^(j*r)*(2.^((1:K)*r)+1)));
    end
    J = -floor(2*log2(2^r-1)/r);
    for j=1:J
        K = ceil((log2(2^(-j*r)+1-2^(-r))-log2(2^r-1))/r);
        psi(r*1024) = psi(r*1024) + sum((1-(1-2^(-r))*2^(j*r)*(2.^((1:K)*r)-1)));
    end
end
psi = psi/2;
semilogy((128:1024)/1024, psi(128:1024));
grid on;
xlabel({'$r$'}, 'interpreter', 'latex', 'fontsize', 16);
legend({'$\psi(1)$', '$\psi(2)$'}, 'interpreter', 'latex', 'fontsize', 16);