clc; clear;

n = 20; r = 1/2;

global hds; % Soft Appeoximation
hds = zeros(1,n);
global hdsapp;  % Hard Approximation
hdsapp = zeros(1,n);
global pmf; % f_{W|d} for d=1..n
pmf = zeros(n,2^(ceil(n*r)+1)+1);
global pmfspecial;  % f_{W|j^{n-1}} for k=1..n
pmfspecial = zeros(n,2^(ceil(n*r)+1)+1);

w = zeros(1,n);
tic;
fhds(n,r,1,w);
toc;

hds = hds./2.^(0:(n-1));
hdsapp = hdsapp./2.^(0:(n-1));
pmf(:, 1:(2^(ceil(n*r)))) = pmf(:, (2^(ceil(n*r)+1)+1):-1:(2^(ceil(n*r))+2));
pmfspecial(:, 1:(2^(ceil(n*r)))) = pmfspecial(:, (2^(ceil(n*r)+1)+1):-1:(2^(ceil(n*r))+2));
for k=1:n
    pmf(k,:) = pmf(k,:) * 2^ceil(n*r)/(nchoosek(n,k)*2^k);
end
pmfspecial = pmfspecial * 2^ceil(n*r)/2^(n-1);

save data_20_10;