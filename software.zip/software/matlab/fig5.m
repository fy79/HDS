load data_20_10;
hdsexp = load('hds20.txt');
hdsbi = ones(1,n);
for k=1:n
    hdsbi(k) = nchoosek(n,k)*(1/(3*(sqrt(2)-1))+0.5)/2^(n*r);
end

hdsfst = ones(1,n);
for k=1:n
    hdsfst(k) = nchoosek(n,k)*2^(-n*r-1)/(2-sqrt(2));
end
hdsfst(n) = 2*hdsfst(n);

semilogy(hdsexp,'-+'); hold on; 
semilogy(hdsbi,'-x'); 
semilogy(hds,'-*'); 
semilogy(hdsapp,'-o');  
semilogy(hdsfst,'-s');
grid on; axis tight;
xlabel({'$d$'}, 'interpreter', 'latex');
ylabel({'$\psi(d;n)$'}, 'interpreter', 'latex');
legend({'EXP','TH-1','TH-2', 'TH-3', 'TH-4'}, 'interpreter', 'latex');
title({'$n=20$, $r=1/2$'}, 'interpreter', 'latex'); % to change figure title here
set(gca,'FontSize',16);

figure(2);
semilogy(n-5:n,hdsexp(n-5:n),'-+'); hold on; 
semilogy(n-5:n,hdsbi(n-5:n),'-x');
semilogy(n-5:n,hds(n-5:n),'-*'); 
semilogy(n-5:n,hdsapp(n-5:n),'-o'); 
semilogy(n-5:n,hdsfst(n-5:n),'-s');
grid on; axis tight;
xlabel({'$d$'}, 'interpreter', 'latex');
ylabel({'$\psi(d;n)$'}, 'interpreter', 'latex');
legend({'EXP','TH-1','TH-2','TH-3','TH-4'}, 'interpreter', 'latex');
title({'$n=20$, $r=1/2$'}, 'interpreter', 'latex'); % to change figure title here
set(gca,'FontSize',16);

